a = {}
a = {1: 1, 2: 4, 3: 9}
print(type(a))
print(a)
keyData = a.keys()
valueData = a.values()
print(keyData)
print(valueData)

# from list
myList = ["a", "b", "c", "d"]
myDict = dict(zip(range(len(myList)), myList))
print(myList)

my_dict = {"name": "yogendra", "age": 24, "city": "varanasi"}
print(my_dict)
print(type(my_dict))

# getting keys and values
print(my_dict.keys(), my_dict.values())

#accessing elemnets
name=my_dict["name"]
age=my_dict["age"]
print(name)
print(age)

#adding & updating
my_dict["country"]="India"
print(my_dict)

my_dict["age"]=25
print(my_dict)

######remove
my_dict.pop("country")
print(my_dict)

my_dict.popitem()#last item pop
print(my_dict)

del my_dict["age"] #using del keyword
print(my_dict)

my_dict.clear() #clear all item from dictionary
print(my_dict)

##iterate through dictionary
for key in my_dict: #iterating key
    print(key)

for value in my_dict.values():
    print(value)
    
for key, value in my_dict.items(): #iterating key-value pair
    print(key,value)
    
#checking keys
if "name" in my_dict:
    print("name is present in my_dict")

if "name" not in my_dict:
    print("name is not present in my_dict") 
else:
    print("name is present in dict")  
    
    
#dictionary method
new_dict=my_dict.copy()#coping elements in new dictionary
print(new_dict)\
    
keys=["name","age","city"]    #creating a dictionary with default value
default_dict=dict.fromkeys(keys,None) 
print(default_dict)     

my_dict.update({"age":26,"city":"Gr Noida",})# updating dictionary with another dictionary
print(my_dict)

      
    
    





