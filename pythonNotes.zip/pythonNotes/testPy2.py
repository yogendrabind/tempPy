
#dir() function
def lazy_range(n):     
       i = 0
       while i < n:
         yield i
       i += 1

for num in lazy_range(10):
   print(num)
   
   
'''isinstance''' 
class Animal:
       pass
class Dog(Animal):
   pass
class Cat(Animal):
   pass

my_dog = Dog()
my_cat = Cat()

print(isinstance(my_dog, Dog))  # True
print(isinstance(my_dog, Animal))  # True, because Dog is a subclass of Animal
print(isinstance(my_dog, Cat))  # False
print(isinstance(my_cat, Cat))  # True
print(isinstance(my_cat, Animal))  # True, because Cat is a subclass of Animal
print(isinstance(my_cat, Dog))  # False

# Checking against a tuple of classes
print(isinstance(my_dog, (Dog, Cat)))  # True
print(isinstance(my_cat, (Dog, Cat)))  # True
print(isinstance(my_dog, (int, float)))  # False   