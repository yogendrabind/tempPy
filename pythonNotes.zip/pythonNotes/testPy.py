def testPy(version):
   print("python", version)
   
testPy(3.12)


# Single-line
# type, dir
 
# def base_func(a,b,c):
#     print("function args", a,b,c)
#     return None
 
# base_func(1,2,3)
 
# base_func(a=1,b=2,c=3) # suggested way.
 
# def base_func2(a,b,c):
#     return a,b,c
 
# a,b,c = base_func2(a=1,b=2,c=3) # suggested way.
# print(a,b,c)
 
# def base_func3(a=[],b={},c=""):
#     if not isinstance(c,str):
#         raise("Validation Error!")
#     return a,b,c
       
 
# a,b,c = base_func3(a=[1,2,3,4,5],b={'a':1},c={'a':1})
 
# print("base Func3",a,b,c)
 
def base5(a=[]):
    yield a
 
# range
a = base5(a=[1,2,3,45]) # lazy iterator
print(a)  

'''
def lazy_range(n):     
       i = 0
       while i < n:
         yield i
       i += 1
# Usage
for num in lazy_range(10):
   print(num)
''' 
   
class Person:
      name = "ram"
      age = 36
      country = "India"
print(dir(Person))