`Visualisation of tower of hanoi`

![1_vVL-OD3M5iCR2HcuXwuD9g](https://github.com/utk2103/Learning_python/assets/118432516/d6137376-3be9-4b87-a644-486e39e02aed)
