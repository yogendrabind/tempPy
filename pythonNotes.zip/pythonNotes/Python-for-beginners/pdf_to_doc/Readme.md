# pdf to docx

### Installation 
```shell
$ pip install pdf2docx
```
```shell
$ pip install --upgrade pdf2docx
```

Uninstall it
```shell
$ pip uninstall pdf2docx
```
