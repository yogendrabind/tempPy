
#code folding
def func1():
    # utka
    # utkasfjh
    # jlfdjlj
    # jrlfjl
    print(func1)


#Make vs code compatible to take the input
# make changes in code runner through settings -> run in terminal 
# -> Clear previous output
# -> Save file before run
print("Hello world")
a = input("Enter a number\n")
print ("Your number is: ", a)


# use of alt+ shift or alt + select to add changes at various places at once
movieList = ["-Inception",
             "-The dep Unchained",
             "-Django Unchained ",
             "-The wolf of wall street ",
             "-SHutter island",
             "-Catch me if you can",
]

for movie in movieList:
    print(f"This is {movieList}")

    # print using code snippet
    print(f"")
    print(f" {a}") 
    
    