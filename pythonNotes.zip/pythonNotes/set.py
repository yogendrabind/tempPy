#unordered, mutable, not allow dublicate
emptySet=set()
print(emptySet)
print(type(emptySet))

fruits={"apple","banana","orange"}
print(type(fruits))

#adding element
fruits.add("grapes")
print(fruits)

#remove
my_set={1,2,3,4}
my_set.pop() # remove first element
print(my_set)

#removing element
my_set.remove(2)
print(my_set) #raise KeyError if element if not found

my_set.discard(2)
print(my_set) #does raise error if element if not found

print(dir(my_set))

#clear all elements

my_set.clear()
print(my_set)
print(len(my_set))

#set operation
set1={1,2,3}
set2={3,4,5}

#union
union_set=set1 | set2 
print(union_set)

union_set2=set1.union(set2)
print(union_set2)

#intersection
intersection_set=set1 & set2
intersection_set

intersection_set2=set1.intersection(set2)
intersection_set2

#difference set
difference_set=set1-set2
difference_set

difference_set2=set1.difference(set2)
difference_set2

#symetric difference
symmetric_difference_set = set1 ^ set2
symmetric_difference_set

symmetric_difference_set2 = set1.symmetric_difference(set2) #not in set1 and set 2 both, opposit of intersection
symmetric_difference_set2

#subset and supersets
is_subset=set1<=set2 #checking all elements of one set in another set
is_subset

is_subset2=set1.issubset(set2)
is_subset2

#proper subset
is_proper_subset=set1<set2 #check if a subset of another set but not equal to it
is_proper_subset


#other useful methods
set_copy=set1.copy()

#Frozenset(Immutable set)
frozen_set=frozenset([1,2,3,4])


