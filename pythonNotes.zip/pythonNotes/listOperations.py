myList=[]
#print(dir(myList))

'''
['__add__', '__class__', '__class_getitem__', '__contains__', '__delattr__', '__delitem__', 
'__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', 
'__getstate__', '__gt__', '__hash__', '__iadd__', '__imul__', '__init__', '__init_subclass__',
'__iter__', '__le__', '__len__', '__lt__', '__mul__', '__ne__', '__new__', '__reduce__', 
'__reduce_ex__', '__repr__', '__reversed__', '__rmul__', '__setattr__', '__setitem__', 
'__sizeof__', '__str__', '__subclasshook__', 'append', 'clear', 'copy', 'count', 'extend', 
'index', 'insert', 'pop', 'remove', 'reverse', 'sort']
'''

#add item on list
myList.append(1)
print(myList)
myList.append(2)
print(myList)
myList.append(3)
print(myList)

#using insert()
myList.insert(2,10)
myList.insert(3,20)

#using extend()
myList.extend([30,40,50])

print(myList)

#get element 
myListdata=[2,3,4,5,6]
myListitem1=myListdata[0]
myListitem2=myListdata[1]
myListitem3=myListdata[2]
myListitem4=myListdata[-1]
myListitem1
myListitem2
myListitem3
myListitem4
print(myListdata[1]+myListdata[-1])

#modify list item
myListdata[2]=10
myListitem3

myListdata
#remove my index
myListdata.pop(1)
#remove by first element
myListdata.remove(6)
myListdata

#remove ele by index
del myListdata[0]
myListdata



#slicing
list1=[1,20,30,4,5]
#basic slicing
sliced_list=list1[1:3] #[20, 30]
sliced_list

#omitting start and stop
sliced_list1=list1[:3]
sliced_list1 ##[1,20,30]

sliced_list2=list1[3:]
sliced_list2 #[4,5]

##using step slicing
list2=[2,3,5,7,11,13,17,23,29]
sliced_list3=list2[::2] #every second element from entire list
sliced_list3  #[2,5,11,17,29]

sliced_list4=list2[2:6:3]# every 3nd elemnt from 1 to 6
sliced_list4   #[5,13]

##negative indices and steps
list3=[2,4,8,16,24,32,64,128,256]
negative_sliced_list1=list3[-3:]#last three element
negative_sliced_list1 #[64,128,256]

negative_sliced_list2=list3[::-1]# all elemnt in reverse order
negative_sliced_list2   #[256, 128, 64, 32, 24, 16, 8, 4, 2]

negative_sliced_list3=list3[::-2]# every second element in reverse order
print(negative_sliced_list3)#[256,64,24,8,2]

#combinning start, stop and step
list4=[2,4,8,16,24,32,64,128,256]
all_sliced_list=list4[2:8:2] # from index 2 to 7, every second elemnt
all_sliced_list

all_sliced_list1=list4[7:1:-2] # from index 7 to 2 in reverse order , every second elemnt
all_sliced_list1   #[128,32,16]


#lenght
length=len(list1)
length

#iterating over list
for i in list1:
    i

#list comprehension
listcomprehension=[i for i in list1]
listcomprehension

#search element

listSearch=[3,4,5,1,2]
data=3 in listSearch
data2=10 in listSearch
data   #true boolean
data2  #false


my__list=[10,40,30,60,50]
##sorting list
my__list.sort()
print (my__list)

#reverse list
my__list.reverse()
my__list

#loop
for i in myListdata:
    if i%2==0:
     print(i)
 
listcomp=[i for i in myListdata if(i%2==0)]
listcomp  
listcomp.append(10)


print(dir(listcomp))   

