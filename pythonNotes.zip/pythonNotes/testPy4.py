
my_dict = {}
my_dict[1]='a'
my_dict[2]='b'
my_dict[3]='c'
print(my_dict)

####
dict ={}
for n in range(10):
      dict[n]=n*2
print (dict)
####
mydict ={n: n*2 for n in range(10) }
print(mydict)

#####
keys={1,2,3}
values={'a','b','c'}
myDict2 = {k: v for (k, v) in zip(keys, values)}
print(myDict2)


######
country=['India','Japan','USA']
capital=['Delhi','Tokyo','WDC']

country_Capital={K:V for (K,V) in zip(country,capital)}
print(country_Capital)

######
country_capital2={}
for (K,V) in zip(country,capital):
    country_capital2[K]=V
print(country_capital2) 


######## 
company=['Google', 'Flipkart', 'Zomato', 'TCS'] 
salary=[200000,120000,90000,30000]

company_montlySalary={}

#using for loop
for (K,V) in zip(company,salary):
    company_montlySalary[K]=V
print(company_montlySalary) 

#using Comprehension
company_montlySalary2={}
company_montlySalary2= {K:V for (K,V) in zip(company,salary)}
print(company_montlySalary2)

    
##Question: What if lists are having different lenghts how to use ZIP on those

list1 = [1, 2, 3]
list2 = ['a', 'b']

zipped = zip(list1,list2)
print(zipped)

zipped = zip(list1,list2)
print(list(zipped))
  
for item1, item2 in zip(list1, list2):
    print(item1, item2)
    print(type(item1))
  
dict_comprehension={}
for item1, item2 in zip(list1, list2): 
    dict_comprehension[item1]=item2  
print(dict_comprehension)  
  
dict_loop={item1:item2 for (item1,item2) in zip(list1,list2)} 
print(dict_loop)

######

file = open('myfile')
print(file.read())
file.close()

file =open('myfile')
print(file.write('hello version 3.12\n'))
file.close()


# Open a file in write mode
with open('file2', 'w') as file:
   file.write("This is the first line.\n")
   file.write("This is the first line.")
   
   
with open('file2','r') as file:
    context=file.read()
    print(context)
    
##nested list comprehension
nestedList=[[1,'a',1],[2,'b',4], [3,'c',9]]

'''
nestedList=[]
for element in nestedList:
    for value in element:
        nestedList.append(value)
        print(nestedList)        
'''       

listData=[value for element in nestedList for value in element]
print(listData)

##find all distict pairs of numbers whose product is even

n=5

ans=[]
for x in range(1,n):
    for y in range(x+1,n):
        if(x*y%2==0):
            ans.append((x,y))
print(ans)

and1=[]
ans1=[(x,y) for x in range(1,n) for y in range(x+1,n) if x*y%2==0]

print(ans1)



   
    
    




 
  
    

 
   


