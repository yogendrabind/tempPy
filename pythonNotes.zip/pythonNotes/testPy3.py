class Person:
      name = "ram"
      age = 36
      country = "India"
print(dir(Person))

list11=[1,2,3]
list2=['a','b','c']

keys = ['a', 'b', 'c', 'd']
values = [1, 2, 3, 4]

mydict = {}

for i in range(len(keys)):
   key = keys[i]
   value = values[i]
   mydict[key] = value
print(mydict) 

my_dict = {keys[i]: values[i] for i in range(len(keys))}
print(my_dict)

''''''
dict ={}
for n in range(10):
      dict[n]=n*2
print (dict)

####creating method using generator
def countdown(n):
       while n > 0:
        yield n
        n -= 1
        
for n in countdown(5):
        print(n)
        
##{'1':1,'2':2,'3':3,'4':4,'5':5} 

dict_data={'1':1,'2':2,'3':3,'4':4,'5':5} 

var=dict_data.keys()
var2=dict_data.values()

print(var)
print(var2)


print(type(var))

listFirst=var[0]
listSecond=var[0]

add_list=listFirst + listSecond
print(add_list)







     