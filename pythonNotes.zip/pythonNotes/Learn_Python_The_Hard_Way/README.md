# Learn_Python_The_Hard_Way

This is from the book Learn Python The Hard Way by Zed A. Shaw. 

## Summary 

All solutions to the problems in the book will be put in this repository.
