#!/usr/bin/python

days = "Mon Tue Wed Thu Fri Sat Sun"
months = "Jan\nFeb\nMar\nApr\nMay\nJun\nJul\nAug"

print("Here are the days: ", days)
print("Here are the months: ", months)

print("""
There's something going on here.
With the three double-qoutes.
We'll be able to type as much as we like.
Even 4 lines if we want, or 5, or 6.
""")
