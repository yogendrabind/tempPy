#!/usr/bin/python

print("hello world!")
print("hello again!")
print("I like typing this.")
print("This is fun.")
print('yay! printing.')
print("I'd much rather you 'not'")
print('I "said" do not touch this.')
