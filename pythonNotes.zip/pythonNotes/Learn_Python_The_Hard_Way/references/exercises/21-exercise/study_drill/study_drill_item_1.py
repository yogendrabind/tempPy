#!/usr/bin/python

# study drill item 1
# 1. If you aren’t really sure what return does, try writing a few of your own functions and have them
# return some values. You can return anything that you can put to the right of an = .

def function1():
    print("function1(): I'll return a string \"this is a string\"")
    return "this is a string"

def function2():
    print("function2(): I'll return an integer 10")
    return 10

# use function1 and function2 

print("calling function1(): ", function1())
print("calling function2(): ", function2())
