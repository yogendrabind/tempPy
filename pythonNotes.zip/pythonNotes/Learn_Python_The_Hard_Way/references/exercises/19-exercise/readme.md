# Study Drills
1. Go back through the script and type a comment above each line explaining in English what it
does.
2. Start at the bottom and read each line backward, saying all the important characters.
3. Write at least one more function of your own design, and run it 10 different ways.
