dict_data={'1':1,'2':2,'3':3,'4':4,'5':5} 

var=dict_data.keys()
var2=dict_data.values()

print(var)
print(var2)


print(type(var))

listFirst=var[0]
listSecond=var2[0]

add_list=listFirst + listSecond
print(add_list)